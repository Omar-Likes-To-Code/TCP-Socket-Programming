package Networks;

import java.io.*;
import java.net.*;

public class TCPServer {
    public static void main(String[] args) throws Exception {
        

        ServerSocket welcomeSocket = new ServerSocket(9999);

        while (true) {
            Socket connectionSocket = welcomeSocket.accept();
            DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());
            BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));

            String connectCommand = inFromClient.readLine();
            if (connectCommand != null && connectCommand.equalsIgnoreCase("CONNECT")) {
                outToClient.writeBytes("Connection established.\n");

                Thread clientHandlerThread = new Thread(() -> {
                    try {
                        while (true) {
                           String receivedMessage = inFromClient.readLine();
                            if (receivedMessage == null || receivedMessage.equalsIgnoreCase("exit")) {
                                System.out.println("Connection closed.");
                                break;
                            }
                            System.out.println("Client: " + receivedMessage);
                        }
                    } catch (IOException e) {
                        // Handle exception
                    }
                });
                clientHandlerThread.start();

                BufferedReader inFromServer = new BufferedReader(new InputStreamReader(System.in));
                while (true) {
                    String message = inFromServer.readLine();
                    if (message == null || message.equalsIgnoreCase("exit")) {
                        System.out.println("Connection closed.");
                        break;
                    }
                    outToClient.writeBytes(message + '\n');
                }

                clientHandlerThread.interrupt();
            } else {
                outToClient.writeBytes("Invalid command. Connection not established.\n");
                connectionSocket.close();
            }
        }
    }
}
