package Networks;

import java.io.*;
import java.net.*;

public class TCPClient {
    public static void main(String[] args) throws Exception {
        String message;
        

        BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
        Socket clientSocket = new Socket("192.168.1.2", 9999);
        DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
        BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

        System.out.println("Type 'CONNECT' to establish a connection.");
        String connectCommand = inFromUser.readLine();
        if (connectCommand != null && connectCommand.equalsIgnoreCase("CONNECT")) {
            outToServer.writeBytes(connectCommand + '\n');

            String connectionMessage = inFromServer.readLine();
            System.out.println("Server: " + connectionMessage);

            if (connectionMessage.equals("Connection established.")) {
                Thread serverHandlerThread = new Thread(() -> {
                    try {
                        while (true) {
                        	String receivedMessage = inFromServer.readLine();
                            if (receivedMessage == null || receivedMessage.equalsIgnoreCase("exit")) {
                                System.out.println("Connection closed.");
                                break;
                            }
                            System.out.println("Server: " + receivedMessage);
                        }
                    } catch (IOException e) {
                        // Handle exception
                    }
                });
                serverHandlerThread.start();

                while (true) {
                    message = inFromUser.readLine();
                    if (message == null || message.equalsIgnoreCase("exit")) {
                        System.out.println("Connection closed.");
                        break;
                    }
                    outToServer.writeBytes(message + '\n');
                }

                serverHandlerThread.interrupt();
            } else {
                System.out.println("Invalid command. Connection not established.");
            }
        } else {
            System.out.println("Invalid command. Connection not established.");
        }

        clientSocket.close();
    }
}